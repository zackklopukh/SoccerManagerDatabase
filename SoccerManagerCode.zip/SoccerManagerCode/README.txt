# Soccer Management System

Zack Klopukh
CPSC 408 Final
12/13

A **Flask** web application for managing players, teams, positions, and player traits in a soccer database. This project connects to a MySQL database to perform CRUD operations and allows users to:

- View players, teams, and positions.
- Add and update player details.
- Search and delete players.
- View players by team.
- Manage player traits.


--
## Errors

- Currently, the update players doesn't fully function
- I never added an option to add traits to a player, so only those with them form the DB have them
- There is no way to generate a report from any data from the app

---

## Features

- **View Players:** Display all players in the database.
- **View Teams:** List all teams and their details.
- **Add Player:** Add a new player with their attributes such as team, position, age, and height.
- **View Players by Team:** Filter players belonging to a specific team.
- **Update Player:** Edit player details and manage their traits.
- **Manage Players:** Search for players and delete them if needed.
- **View Player Traits:** Display traits acquired by a player.

---

## Technologies Used

- **Python** (Flask Framework)
- **MySQL** (Relational Database Management)
- **HTML/CSS** (Frontend Templates)
- **Bootstrap** (UI Enhancements)
- **ChatGPT** (Database Generation)

---

## Installation

Follow these steps to set up the project:

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-repository/soccer-management.git
   cd soccer-management
   ```

2. **Create a virtual environment** (optional but recommended):
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows, use venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install flask flask-mysql
   ```

4. **Configure MySQL**:
   - Create a database named `soccer_db`.
   - Run the provided SQL script (`schema.sql`) to set up tables.

5. **Run the application**:
   ```bash
   flask run
   ```
   Access the app at `http://127.0.0.1:5000`.

---

### Main Menu
- **`/`** - Displays the main menu with navigation options.

### View Routes
- **`/view_players`** - List all players with their details.
- **`/view_teams`** - View all teams in the database.
- **`/view_team/<int:team_id>`** - View players associated with a specific team.
- **`/view_player_traits/<int:player_id>`** - Display traits acquired by a player.

### Add and Manage Routes
- **`/add_player`** - Add a new player to the database.
- **`/update_player/<int:player_id>`** - Update details of an existing player and manage their traits.
- **`/manage_players`** - Search for players and delete them.

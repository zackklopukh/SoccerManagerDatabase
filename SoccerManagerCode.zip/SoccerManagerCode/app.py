from flask import Flask, render_template
from flask_mysqldb import MySQL
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# MySQL configuration
app.config['MYSQL_HOST'] = 'localhost'  # Replace with your host
app.config['MYSQL_USER'] = 'root'  # Replace with your MySQL username
app.config['MYSQL_PASSWORD'] = '7804'  # Replace with your MySQL password
app.config['MYSQL_DB'] = 'SoccerManager'  # Replace with your database name

mysql = MySQL(app)

@app.route('/')
def main_menu():
    return render_template('main_menu.html')

@app.route('/view_players')
def view_players():
    try:
        # Connect to the database and fetch the Players table, ordered by Team and Name
        cur = mysql.connection.cursor()
        cur.execute("""
            SELECT p.PlayerID, p.Name, p.Age, p.Height, pos.PositionName, 
                   p.OffensiveCapabilities, p.DefensiveCapabilities, p.SpecialNotes, 
                   t.Name AS TeamName
            FROM Players p
            JOIN Positions pos ON p.PositionID = pos.PositionID
            JOIN Teams t ON p.TeamID = t.TeamID
            ORDER BY t.Name ASC, p.Name ASC;  -- Sorted first by TeamName, then PlayerName in ascending order
        """)
        players = cur.fetchall()  # Fetch all rows from the query
        
        # Define column names for the table
        column_names = ["PlayerID", "Name", "Age", "Height", "Position", 
                        "Offensive Capabilities", "Defensive Capabilities", 
                        "Special Notes", "Team"]
        
        cur.close()
        return render_template('view_players.html', column_names=column_names, players=players)
    except Exception as e:
        return f"An error occurred: {e}"


@app.route('/view_teams')
def display_teams():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM Teams;")
        teams = cur.fetchall()
        column_names = ["TeamID", "Name", "Coach", "HomeColor", "AwayColor", "Stadium", "Wins", "Losses", "Ties"]
        cur.close()
        return render_template('teams.html', column_names=column_names, teams=teams)
    except Exception as e:
        return f"An error occurred: {e}"




@app.route('/add_player', methods=['GET', 'POST'])
def add_player():
    if request.method == 'POST':
        # Retrieve data from the form
        name = request.form['name']
        age = request.form['age']
        height = request.form['height']
        position_id = request.form['position']
        offense = request.form['offense']
        defense = request.form['defense']
        notes = request.form.get('notes', '')  # Default to empty if not provided
        team_id = request.form['team']

        try:
            # Insert data into the database
            cur = mysql.connection.cursor()
            query = """
                INSERT INTO Players (Name, Age, Height, PositionID, OffensiveCapabilities, 
                DefensiveCapabilities, SpecialNotes, TeamID)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(query, (name, age, height, position_id, offense, defense, notes, team_id))
            mysql.connection.commit()
            cur.close()
            return redirect(url_for('add_player'))  # Redirect to the same page
        except Exception as e:
            return f"An error occurred: {e}"

    # For GET requests, fetch the dropdown options
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT PositionID, PositionName FROM Positions")
        positions = cur.fetchall()  # Fetch all positions for the dropdown

        cur.execute("SELECT TeamID, Name FROM Teams")
        teams = cur.fetchall()  # Fetch all teams for the dropdown

        cur.close()
    except Exception as e:
        return f"An error occurred while fetching options: {e}"

    return render_template('add_player.html', positions=positions, teams=teams)




@app.route('/view_team/<int:team_id>')
def view_team(team_id):
    try:
        cur = mysql.connection.cursor()
        
        # Fetch team information
        cur.execute("SELECT * FROM Teams WHERE TeamID = %s;", (team_id,))
        team_info = cur.fetchone()
        if not team_info:
            return "Team not found", 404
        
        # Fetch players associated with the team
        query = """
             SELECT p.PlayerID, p.Name, p.Age, p.Height, pos.PositionName, 
                    p.OffensiveCapabilities, p.DefensiveCapabilities, p.SpecialNotes
             FROM Players p
             LEFT JOIN Positions pos ON p.PositionID = pos.PositionID
             WHERE p.TeamID = %s
             ORDER BY pos.PositionName ASC, p.Name ASC;
         """
        cur.execute(query, (team_id,))
        players = cur.fetchall()

        # Define column names for the players
        player_columns = [
             "PlayerID", "Name", "Age", "Height", "Position", 
             "OffensiveCapabilities", "DefensiveCapabilities", "SpecialNotes"
        ]
        
        # Convert each player tuple into a dictionary with column names as keys
        players = [dict(zip(player_columns, player)) for player in players]
        
        query_tactics = """
            SELECT tt.Name, tt.Description
            FROM AcquiredTeamTactics at
            JOIN TeamTactics tt ON at.TacticID = tt.TacticID
            WHERE at.TeamID = %s;
        """
        cur.execute(query_tactics, (team_id,))
        teamTactics = cur.fetchall()
        
        cur.close()
        
        # Pass the team and players data to the template
        return render_template(
            'view_team.html', 
            team=dict(zip(
                ["TeamID", "Name", "Coach", "HomeColor", "AwayColor", "Stadium", "Wins", "Ties", "Losses"], 
                team_info)
            ),
            teamTactics = teamTactics,
            players=players  # Pass the list of players (now as dictionaries)
        )
    
    except Exception as e:
        return f"An error occurred: {e}"



@app.route('/view_player_traits/<int:player_id>')
def view_player_traits(player_id):
    try:
        cur = mysql.connection.cursor()
        
        # Fetch player information
        cur.execute("SELECT * FROM Players WHERE PlayerID = %s;", (player_id,))
        player_info = cur.fetchone()
        if not player_info:
            return "Player not found", 404
        
        
        cur.execute("""
            SELECT at.TraitID, pt.Name
            FROM AcquiredTraits at
            JOIN PlayerTraits pt ON at.TraitID = pt.TraitID
            WHERE at.PlayerID = %s;
        """, (player_id,))
        traits = cur.fetchall()
        
        cur.close()
        # Pass the data to the template
        return render_template(
            'view_player_traits.html', 
            player=dict(zip(["PlayerID", "Name", "Age", "Height", "Position", "OffensiveCapabilities", "DefensiveCapabilities", "SpecialNotes"], player_info)),
            traits=traits  # List of traits
        )
    except Exception as e:
        return f"An error occurred: {e}"


@app.route('/manage_players', methods=['GET', 'POST'])
def manage_players():
    try:
        cur = mysql.connection.cursor()
        
        if request.method == 'POST' and 'player_id' in request.form:
            player_id = request.form.get('player_id')

            # Delete the player's traits first (if they're stored in a separate table like AcquiredTraits)
            delete_traits_query = "DELETE FROM AcquiredTraits WHERE PlayerID = %s;"
            cur.execute(delete_traits_query, (player_id,))
            
            # Then delete the player from the Players table
            delete_player_query = "DELETE FROM Players WHERE PlayerID = %s;"
            cur.execute(delete_player_query, (player_id,))
            
            # Commit the transaction to save changes to the database
            mysql.connection.commit()

            # Close the cursor after executing the queries
            cur.close()

            # Display success message
            message = f"Player with ID {player_id} and their associated traits deleted successfully."
            return render_template('success.html', message=message)
        
        # Handle GET request to display players
        search_query = request.args.get('search', '')
        if search_query:
            query = """
                SELECT p.PlayerID, p.Name, p.Age, p.Height, pos.PositionName, t.Name AS TeamName
                FROM Players p
                LEFT JOIN Positions pos ON p.PositionID = pos.PositionID
                LEFT JOIN Teams t ON p.TeamID = t.TeamID
                WHERE p.Name LIKE %s OR t.Name LIKE %s
                ORDER BY p.Name ASC;
            """
            cur.execute(query, (f"%{search_query}%", f"%{search_query}%"))
        else:
            query = """
                SELECT p.PlayerID, p.Name, p.Age, p.Height, pos.PositionName, t.Name AS TeamName
                FROM Players p
                LEFT JOIN Positions pos ON p.PositionID = pos.PositionID
                LEFT JOIN Teams t ON p.TeamID = t.TeamID
                ORDER BY p.Name ASC;
            """
            cur.execute(query)

        players = cur.fetchall()
        cur.close()

        # Define column names for rendering
        column_names = ["PlayerID", "Name", "Age", "Height", "Position", "Team"]

        return render_template(
            'manage_players.html',
            players=players,
            column_names=column_names,
            search_query=search_query,
            message=message if request.method == 'POST' else None
        )
    except Exception as e:
        return f"An error occurred: {e}"

    
@app.route('/update_player/<int:player_id>', methods=['GET', 'POST'])
def update_player(player_id):
    try:
        cur = mysql.connection.cursor()

        if request.method == 'POST':
            # Retrieve updated data from the form
            name = request.form['name']
            age = request.form['age']
            height = request.form['height']
            position_id = request.form['position']
            offense = request.form['offense']
            defense = request.form['defense']
            notes = request.form.get('notes', '')  # Default to empty if not provided
            team_id = request.form['team']

            # Handle deletion of specific trait(s)
            if request.method == 'POST' and 'player_id' in request.form:
                delete_trait = request.form['delete_trait']

                # Delete the selected trait from the AcquiredTraits table
                delete_trait_query = "DELETE FROM AcquiredTraits WHERE TraitID = %s;"
                cur.execute(delete_trait_query, (delete_trait))
                mysql.connection.commit()
                cur.close()
                redirect(url_for('update_player'))

            # Update the player's data in the database
            query = """
                UPDATE Players
                SET Name = %s, Age = %s, Height = %s, PositionID = %s,
                    OffensiveCapabilities = %s, DefensiveCapabilities = %s,
                    SpecialNotes = %s, TeamID = %s
                WHERE PlayerID = %s;
            """
            cur.execute(query, (name, age, height, position_id, offense, defense, notes, team_id, player_id))
            mysql.connection.commit()
            cur.close()

            return redirect(url_for('manage_players'))

        # Fetch player details for the GET request
        cur.execute("SELECT * FROM Players WHERE PlayerID = %s;", (player_id,))
        player = cur.fetchone()

        cur.execute("SELECT PositionID, PositionName FROM Positions")
        positions = cur.fetchall()

        cur.execute("SELECT TeamID, Name FROM Teams")
        teams = cur.fetchall()

        cur.execute("""
            SELECT at.TraitID, pt.Name
            FROM AcquiredTraits at
            JOIN PlayerTraits pt ON at.TraitID = pt.TraitID
            WHERE at.PlayerID = %s;
        """, (player_id,))
        traits = cur.fetchall()

        cur.close()

        # Define column names for player attributes
        player_columns = [
            "PlayerID", "Name", "Age", "Height", "PositionID", 
            "OffensiveCapabilities", "DefensiveCapabilities", "SpecialNotes", "TeamID"
        ]

        return render_template(
            'update_player.html', 
            player=dict(zip(player_columns, player)),
            positions=positions,
            teams=teams,
            traits=traits,
            #traitIDs=traitIDs
        )
    except Exception as e:
        return f"An error occurred: {e}"


@app.route('/view_played_games')
def view_played_games():
    try:
        cur = mysql.connection.cursor()
        cur.execute("""
            SELECT g.GameID, ht.Name AS HomeTeam, at.Name AS AwayTeam, g.Time, g.HomeGoals, g.AwayGoals
            FROM Games g
            JOIN Teams ht ON g.HomeTeamID = ht.TeamID
            JOIN Teams at ON g.AwayTeamID = at.TeamID
            WHERE g.HomeGoals IS NOT NULL AND g.AwayGoals IS NOT NULL
            ORDER BY g.Time DESC;
        """)
        games = cur.fetchall()
        cur.close()
        return render_template('view_played_games.html', games=games)
    except Exception as e:
        return f"An error occurred: {e}"


@app.route('/view_unplayed_games')
def view_unplayed_games():
    try:
        cur = mysql.connection.cursor()
        cur.execute("""
            SELECT g.GameID, ht.Name AS HomeTeam, at.Name AS AwayTeam, g.Time, g.HomeGoals, g.AwayGoals
            FROM Games g
            JOIN Teams ht ON g.HomeTeamID = ht.TeamID
            JOIN Teams at ON g.AwayTeamID = at.TeamID
            WHERE g.HomeGoals IS NULL AND g.AwayGoals IS NULL
            ORDER BY g.Time DESC;
        """)
        games = cur.fetchall()
        cur.close()
        return render_template('view_unplayed_games.html', games=games)
    except Exception as e:
        return f"An error occurred: {e}"




@app.route('/add_game', methods=['GET', 'POST'])
def add_game():
    if request.method == 'POST':
        # Retrieve form data
        home_team_id = request.form['home_team']
        away_team_id = request.form['away_team']
        time = request.form['time']

        try:
            # Insert new game into the database
            cur = mysql.connection.cursor()
            query = """
                INSERT INTO Games (HomeTeamID, AwayTeamID, Time)
                VALUES (%s, %s, %s)
            """
            cur.execute(query, (home_team_id, away_team_id, time))
            mysql.connection.commit()
            cur.close()
            
            # Redirect to the game list or another page after adding the game
            return redirect(url_for('view_unplayed_games'))
        
        except Exception as e:
            return f"An error occurred: {e}"

    # For GET requests, fetch the teams for dropdowns
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT TeamID, Name FROM Teams")
        teams = cur.fetchall()
        cur.close()
    except Exception as e:
        return f"An error occurred while fetching teams: {e}"

    return render_template('add_game.html', teams=teams)

@app.route('/play_game', methods=['POST'])
def play_game():
    try:
        game_id = request.form.get('game_id')
        home_goals = int(request.form.get('home_goals'))
        away_goals = int(request.form.get('away_goals'))

        cur = mysql.connection.cursor()

        # Step 1: Update the game's scores
        cur.execute("""
            UPDATE Games 
            SET HomeGoals = %s, AwayGoals = %s
            WHERE GameID = %s;
        """, (home_goals, away_goals, game_id))

        # Step 2: Retrieve the team IDs for the game
        cur.execute("""
            SELECT HomeTeamID, AwayTeamID FROM Games WHERE GameID = %s;
        """, (game_id,))
        game_data = cur.fetchone()

        home_team_id = game_data[0]
        away_team_id = game_data[1]

        # Step 3: Update the teams' statistics (Wins, Losses, Ties)
        if home_goals > away_goals:
            # Home team wins, away team loses
            cur.execute("""
                UPDATE Teams SET Wins = Wins + 1 WHERE TeamID = %s;
            """, (home_team_id,))
            cur.execute("""
                UPDATE Teams SET Losses = Losses + 1 WHERE TeamID = %s;
            """, (away_team_id,))
        elif away_goals > home_goals:
            # Away team wins, home team loses
            cur.execute("""
                UPDATE Teams SET Wins = Wins + 1 WHERE TeamID = %s;
            """, (away_team_id,))
            cur.execute("""
                UPDATE Teams SET Losses = Losses + 1 WHERE TeamID = %s;
            """, (home_team_id,))
        else:
            # It's a tie: Both teams have equal goals
            cur.execute("""
                UPDATE Teams SET Ties = Ties + 1 WHERE TeamID = %s;
            """, (home_team_id,))
            cur.execute("""
                UPDATE Teams SET Ties = Ties + 1 WHERE TeamID = %s;
            """, (away_team_id,))

        # Commit the transaction
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('view_played_games'))  # Redirect to the played games view
    except Exception as e:
        return f"An error occurred: {e}"








if __name__ == '__main__':
    app.run(debug=True)
